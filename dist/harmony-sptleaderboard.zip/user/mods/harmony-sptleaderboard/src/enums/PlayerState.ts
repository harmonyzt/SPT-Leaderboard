// Previously a map, turned into an enum - cj
export enum PlayerState
{
    ONLINE = "online",
    IN_MENU = "in_menu",
    IN_RAID = "in_raid",
    IN_STASH = "in_stash"
}